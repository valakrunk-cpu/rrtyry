export const API_CONFIG = {
  FIVEM_API_BASE: 'https://servers-frontend.fivem.net/api/servers',
  TIMEOUT: 10000,
  MAX_RETRIES: 3,
  CONCURRENT_DOWNLOADS: 5
} as const;

export const UI_CONFIG = {
  PARTICLE_COUNT: 50,
  CONNECTION_DISTANCE: 80,
  PARTICLE_SPEED: 0.5,
  ANIMATION_INTERVAL: 16
} as const;

export const STATUS_COLORS = {
  online: { bg: 'bg-green-400/20', text: 'text-green-400', border: 'border-green-400' },
  offline: { bg: 'bg-red-400/20', text: 'text-red-400', border: 'border-red-400' },
  loading: { bg: 'bg-yellow-400/20', text: 'text-yellow-400', border: 'border-yellow-400' },
  error: { bg: 'bg-red-400/20', text: 'text-red-400', border: 'border-red-400' }
} as const;

export const RESOURCE_STATUS = {
  running: { color: 'green', label: 'Running' },
  stopped: { color: 'red', label: 'Stopped' },
  starting: { color: 'yellow', label: 'Starting' },
  error: { color: 'red', label: 'Error' }
} as const;