import { createClient } from '@supabase/supabase-js';

// Supabase configuration
const supabaseUrl = process.env.REACT_APP_SUPABASE_URL || 'YOUR_SUPABASE_URL';
const supabaseKey = process.env.REACT_APP_SUPABASE_ANON_KEY || 'YOUR_SUPABASE_ANON_KEY';

export const supabase = createClient(supabaseUrl, supabaseKey);

// UDG Key validation interface
export interface UDGKey {
  id: string;
  key: string;
  is_active: boolean;
  created_at: string;
  expires_at?: string;
  usage_count: number;
  max_usage?: number;
}

// UDG Key service
export class UDGKeyService {
  /**
   * Validate UDG V 5.0 key against Supabase database
   */
  static async validateKey(key: string): Promise<{ valid: boolean; message: string; keyData?: UDGKey }> {
    try {
      // Check key format first
      if (!key || !key.match(/^UDG-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/)) {
        return {
          valid: false,
          message: 'Invalid UDG V 5.0 KEY format. Expected: UDG-XXXX-XXXX-XXXX'
        };
      }

      // Query Supabase for the key
      const { data, error } = await supabase
        .from('udg_keys')
        .select('*')
        .eq('key', key)
        .eq('is_active', true)
        .single();

      if (error) {
        console.error('Supabase query error:', error);
        return {
          valid: false,
          message: 'Key validation failed. Please check your connection.'
        };
      }

      if (!data) {
        return {
          valid: false,
          message: 'Invalid or expired UDG V 5.0 KEY'
        };
      }

      // Check if key has expired
      if (data.expires_at && new Date(data.expires_at) < new Date()) {
        return {
          valid: false,
          message: 'UDG V 5.0 KEY has expired'
        };
      }

      // Check usage limits
      if (data.max_usage && data.usage_count >= data.max_usage) {
        return {
          valid: false,
          message: 'UDG V 5.0 KEY usage limit exceeded'
        };
      }

      // Key is valid, increment usage count
      await this.incrementUsage(key);

      return {
        valid: true,
        message: 'UDG V 5.0 KEY authenticated successfully',
        keyData: data
      };

    } catch (error) {
      console.error('Key validation error:', error);
      return {
        valid: false,
        message: 'Key validation service unavailable'
      };
    }
  }

  /**
   * Increment usage count for a key
   */
  static async incrementUsage(key: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('udg_keys')
        .update({ 
          usage_count: supabase.raw('usage_count + 1'),
          last_used_at: new Date().toISOString()
        })
        .eq('key', key);

      if (error) {
        console.error('Failed to increment usage:', error);
      }
    } catch (error) {
      console.error('Usage increment error:', error);
    }
  }

  /**
   * Get key information (for admin purposes)
   */
  static async getKeyInfo(key: string): Promise<UDGKey | null> {
    try {
      const { data, error } = await supabase
        .from('udg_keys')
        .select('*')
        .eq('key', key)
        .single();

      if (error || !data) {
        return null;
      }

      return data;
    } catch (error) {
      console.error('Get key info error:', error);
      return null;
    }
  }
}

// Database schema for reference:
/*
CREATE TABLE udg_keys (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  key VARCHAR(17) UNIQUE NOT NULL,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  expires_at TIMESTAMP WITH TIME ZONE,
  usage_count INTEGER DEFAULT 0,
  max_usage INTEGER,
  last_used_at TIMESTAMP WITH TIME ZONE,
  created_by VARCHAR(255),
  notes TEXT
);

-- Create index for faster key lookups
CREATE INDEX idx_udg_keys_key ON udg_keys(key);
CREATE INDEX idx_udg_keys_active ON udg_keys(is_active);
*/