import axios, { AxiosResponse } from 'axios';

export interface FiveMServer {
  EndPoint: string;
  Data: {
    clients: number;
    gametype: string;
    hostname: string;
    mapname: string;
    sv_maxclients: number;
    resources: string[];
    server: string;
    vars: Record<string, any>;
  };
}

export interface FiveMServerList {
  Data: FiveMServer[];
}

class FiveMApiService {
  private readonly baseUrl = 'https://servers-frontend.fivem.net/api/servers';
  private readonly timeout = 10000;

  async getServerInfo(ip: string, port: number): Promise<FiveMServer | null> {
    try {
      const endpoint = `${ip}:${port}`;
      const response: AxiosResponse<FiveMServer> = await axios.get(
        `${this.baseUrl}/single/${endpoint}`,
        {
          timeout: this.timeout,
          headers: {
            'Accept': 'application/json',
            'User-Agent': 'FiveM-Resource-Downloader/1.0'
          }
        }
      );

      return response.data;
    } catch (error) {
      console.error('Failed to fetch server info from FiveM API:', error);
      return null;
    }
  }

  async searchServers(query: string, limit: number = 50): Promise<FiveMServer[]> {
    try {
      const response: AxiosResponse<FiveMServerList> = await axios.get(
        `${this.baseUrl}`,
        {
          params: {
            q: query,
            limit
          },
          timeout: this.timeout,
          headers: {
            'Accept': 'application/json',
            'User-Agent': 'FiveM-Resource-Downloader/1.0'
          }
        }
      );

      return response.data.Data || [];
    } catch (error) {
      console.error('Failed to search servers:', error);
      return [];
    }
  }

  async getPopularServers(limit: number = 100): Promise<FiveMServer[]> {
    try {
      const response: AxiosResponse<FiveMServerList> = await axios.get(
        `${this.baseUrl}`,
        {
          params: {
            limit,
            sortBy: 'clients'
          },
          timeout: this.timeout,
          headers: {
            'Accept': 'application/json',
            'User-Agent': 'FiveM-Resource-Downloader/1.0'
          }
        }
      );

      return response.data.Data || [];
    } catch (error) {
      console.error('Failed to fetch popular servers:', error);
      return [];
    }
  }

  async analyzeServerResources(ip: string, port: number): Promise<{
    totalResources: number;
    resourceTypes: Record<string, number>;
    commonResources: string[];
    customResources: string[];
  }> {
    try {
      const serverInfo = await this.getServerInfo(ip, port);
      
      if (!serverInfo?.Data?.resources) {
        return {
          totalResources: 0,
          resourceTypes: {},
          commonResources: [],
          customResources: []
        };
      }

      const resources = serverInfo.Data.resources;
      const commonResourcePrefixes = [
        'esx_', 'vrp_', 'qb-', 'ox_', 'mythic_', 'standalone_',
        'chat', 'hardcap', 'mapmanager', 'spawnmanager', 'sessionmanager'
      ];

      const resourceTypes: Record<string, number> = {};
      const commonResources: string[] = [];
      const customResources: string[] = [];

      resources.forEach(resource => {
        // Categorize by prefix
        const prefix = resource.split('_')[0] + '_';
        resourceTypes[prefix] = (resourceTypes[prefix] || 0) + 1;

        // Separate common vs custom
        const isCommon = commonResourcePrefixes.some(commonPrefix => 
          resource.toLowerCase().startsWith(commonPrefix.toLowerCase())
        );

        if (isCommon) {
          commonResources.push(resource);
        } else {
          customResources.push(resource);
        }
      });

      return {
        totalResources: resources.length,
        resourceTypes,
        commonResources,
        customResources
      };
    } catch (error) {
      console.error('Failed to analyze server resources:', error);
      return {
        totalResources: 0,
        resourceTypes: {},
        commonResources: [],
        customResources: []
      };
    }
  }
}

export const fivemApi = new FiveMApiService();