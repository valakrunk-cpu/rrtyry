import React, { useState } from 'react';
import { User, Shield, Ban, MessageCircle } from 'lucide-react';

interface Player {
  id: string;
  name: string;
  ping: number;
  playtime: string;
  status: 'online' | 'afk' | 'admin';
}

interface PlayerListProps {
  compact?: boolean;
}

const PlayerList: React.FC<PlayerListProps> = ({ compact = false }) => {
  const [players] = useState<Player[]>([
    { id: '1', name: 'Admin_Zeus', ping: 32, playtime: '4h 23m', status: 'admin' },
    { id: '2', name: 'CyberNinja47', ping: 45, playtime: '2h 15m', status: 'online' },
    { id: '3', name: 'QuantumGamer', ping: 67, playtime: '6h 42m', status: 'online' },
    { id: '4', name: 'NeoMatrix99', ping: 156, playtime: '1h 33m', status: 'afk' },
    { id: '5', name: 'EliteHacker', ping: 23, playtime: '8h 17m', status: 'online' },
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'text-green-400';
      case 'afk': return 'text-yellow-400';
      case 'admin': return 'text-purple-400';
      default: return 'text-gray-400';
    }
  };

  const getPingColor = (ping: number) => {
    if (ping < 50) return 'text-green-400';
    if (ping < 100) return 'text-yellow-400';
    return 'text-red-400';
  };

  const displayedPlayers = compact ? players.slice(0, 4) : players;

  return (
    <div className="glass-morphism p-6 rounded-xl border border-gray-700">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-semibold text-white">Active Players</h3>
        <span className="text-sm text-gray-400">{players.length}/128</span>
      </div>

      <div className="space-y-3">
        {displayedPlayers.map((player, index) => (
          <div
            key={player.id}
            className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg border border-gray-700 hover:border-cyan-400/30 transition-all duration-300"
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <div className="flex items-center space-x-3">
              <div className={`w-2 h-2 rounded-full bg-${player.status === 'online' ? 'green' : player.status === 'afk' ? 'yellow' : 'purple'}-400 animate-pulse`}></div>
              
              <div>
                <div className="flex items-center space-x-2">
                  <span className="font-medium text-white">{player.name}</span>
                  {player.status === 'admin' && (
                    <Shield className="w-3 h-3 text-purple-400" />
                  )}
                </div>
                <div className="flex items-center space-x-3 text-xs text-gray-400">
                  <span>Playtime: {player.playtime}</span>
                  <span className={getPingColor(player.ping)}>
                    {player.ping}ms
                  </span>
                </div>
              </div>
            </div>

            {!compact && (
              <div className="flex items-center space-x-2">
                <button className="p-1 text-blue-400 hover:bg-blue-400/20 rounded border border-blue-400/30 hover:border-blue-400/50 transition-all">
                  <MessageCircle className="w-3 h-3" />
                </button>
                
                <button className="p-1 text-red-400 hover:bg-red-400/20 rounded border border-red-400/30 hover:border-red-400/50 transition-all">
                  <Ban className="w-3 h-3" />
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {compact && (
        <div className="mt-4 text-center">
          <button className="text-cyan-400 hover:text-cyan-300 text-sm">
            View All Players →
          </button>
        </div>
      )}
    </div>
  );
};

export default PlayerList;