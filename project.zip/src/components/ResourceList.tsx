import React, { useState } from 'react';
import { Play, Square, RefreshCw, Download, Trash2 } from 'lucide-react';

interface Resource {
  id: string;
  name: string;
  status: 'running' | 'stopped' | 'error';
  type: 'script' | 'map' | 'vehicle' | 'weapon';
  version: string;
  description: string;
}

interface ResourceListProps {
  onAction: () => void;
  compact?: boolean;
}

const ResourceList: React.FC<ResourceListProps> = ({ onAction, compact = false }) => {
  const [resources] = useState<Resource[]>([
    { id: '1', name: 'esx_core', status: 'running', type: 'script', version: '1.9.4', description: 'Essential Extended framework' },
    { id: '2', name: 'qb-policejob', status: 'running', type: 'script', version: '2.1.0', description: 'Advanced police job system' },
    { id: '3', name: 'custom_vehicles', status: 'stopped', type: 'vehicle', version: '1.0.0', description: 'Custom vehicle pack' },
    { id: '4', name: 'los_santos_map', status: 'running', type: 'map', version: '3.2.1', description: 'Enhanced Los Santos map' },
    { id: '5', name: 'weapon_pack', status: 'error', type: 'weapon', version: '2.0.5', description: 'Extended weapon collection' },
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'text-green-400';
      case 'stopped': return 'text-gray-400';
      case 'error': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getStatusBg = (status: string) => {
    switch (status) {
      case 'running': return 'bg-green-400/20 border-green-400/50';
      case 'stopped': return 'bg-gray-400/20 border-gray-400/50';
      case 'error': return 'bg-red-400/20 border-red-400/50';
      default: return 'bg-gray-400/20 border-gray-400/50';
    }
  };

  const displayedResources = compact ? resources.slice(0, 3) : resources;

  return (
    <div className="glass-morphism p-6 rounded-xl border border-gray-700">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-semibold text-white">Resources</h3>
        <div className="flex space-x-2">
          <button className="px-3 py-1 bg-cyan-400/20 text-cyan-400 rounded-lg border border-cyan-400/50 text-sm hover:bg-cyan-400/30 transition-all">
            Refresh All
          </button>
          {!compact && (
            <button className="px-3 py-1 bg-green-400/20 text-green-400 rounded-lg border border-green-400/50 text-sm hover:bg-green-400/30 transition-all">
              Install New
            </button>
          )}
        </div>
      </div>

      <div className="space-y-3">
        {displayedResources.map((resource, index) => (
          <div
            key={resource.id}
            className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg border border-gray-700 hover:border-cyan-400/30 transition-all duration-300"
            style={{ animationDelay: `${index * 100}ms` }}
          >
            <div className="flex items-center space-x-4">
              <div className={`w-3 h-3 rounded-full ${getStatusBg(resource.status)} border`}></div>
              
              <div>
                <h4 className="font-medium text-white">{resource.name}</h4>
                <p className="text-sm text-gray-400">{resource.description}</p>
                {!compact && (
                  <div className="flex items-center space-x-4 mt-1">
                    <span className="text-xs text-gray-500">v{resource.version}</span>
                    <span className="text-xs text-gray-500 capitalize">{resource.type}</span>
                    <span className={`text-xs ${getStatusColor(resource.status)} capitalize`}>
                      {resource.status}
                    </span>
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center space-x-2">
              {resource.status === 'running' ? (
                <button
                  onClick={onAction}
                  className="p-2 text-red-400 hover:bg-red-400/20 rounded-lg border border-red-400/30 hover:border-red-400/50 transition-all group"
                >
                  <Square className="w-4 h-4 group-hover:scale-110 transition-transform" />
                </button>
              ) : (
                <button
                  onClick={onAction}
                  className="p-2 text-green-400 hover:bg-green-400/20 rounded-lg border border-green-400/30 hover:border-green-400/50 transition-all group"
                >
                  <Play className="w-4 h-4 group-hover:scale-110 transition-transform" />
                </button>
              )}

              {!compact && (
                <>
                  <button className="p-2 text-blue-400 hover:bg-blue-400/20 rounded-lg border border-blue-400/30 hover:border-blue-400/50 transition-all">
                    <RefreshCw className="w-4 h-4" />
                  </button>
                  
                  <button className="p-2 text-gray-400 hover:bg-gray-400/20 rounded-lg border border-gray-400/30 hover:border-gray-400/50 transition-all">
                    <Download className="w-4 h-4" />
                  </button>

                  <button className="p-2 text-red-400 hover:bg-red-400/20 rounded-lg border border-red-400/30 hover:border-red-400/50 transition-all">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </>
              )}
            </div>
          </div>
        ))}
      </div>

      {compact && (
        <div className="mt-4 text-center">
          <button className="text-cyan-400 hover:text-cyan-300 text-sm">
            View All Resources →
          </button>
        </div>
      )}
    </div>
  );
};

export default ResourceList;