import React, { useState, useEffect, useRef } from 'react';
import { Terminal, Activity, CheckCircle, AlertTriangle, Download } from 'lucide-react';
import { DownloadProgress } from '../utils/fivemDownloader';

interface DecryptionConsoleProps {
  isActive: boolean;
  progress: number;
  downloadProgress?: DownloadProgress[];
}

const DecryptionConsole: React.FC<DecryptionConsoleProps> = ({ isActive, progress, downloadProgress = [] }) => {
  const [logs, setLogs] = useState<Array<{
    id: string;
    type: 'info' | 'success' | 'warning' | 'error';
    message: string;
    timestamp: string;
  }>>([]);
  
  const consoleRef = useRef<HTMLDivElement>(null);

  const addLog = (type: 'info' | 'success' | 'warning' | 'error', message: string) => {
    const newLog = {
      id: crypto.randomUUID(),
      type,
      message,
      timestamp: new Date().toLocaleTimeString()
    };
    
    setLogs(prev => [...prev.slice(-49), newLog]); // Keep only last 50 logs
  };

  useEffect(() => {
    if (isActive && downloadProgress.length === 0) {
      const totalSizeGB = Math.floor(Math.random() * 40 + 40);
      const resourceCount = Math.floor(Math.random() * 20 + 25);
      
      const initLogs = [
        { type: 'info' as const, msg: '🚀 Initializing FXAP decryption engine...', delay: 0 },
        { type: 'info' as const, msg: '🔧 Loading modified FiveM DLL components...', delay: 300 },
        { type: 'success' as const, msg: '✓ FiveM.exe patched successfully', delay: 600 },
        { type: 'success' as const, msg: '✓ CitizenFX.Core.dll modified', delay: 900 },
        { type: 'success' as const, msg: '✓ CitizenGame.dll bypass loaded', delay: 1200 },
        { type: 'success' as const, msg: '✓ CitizenMP.Server.dll patched', delay: 1500 },
        { type: 'success' as const, msg: '✓ CitizenScripting.Core.dll modified', delay: 1800 },
        { type: 'success' as const, msg: '✓ CitizenScripting.v8.dll bypassed', delay: 2100 },
        { type: 'success' as const, msg: '✓ ScriptHookV.dll bypass loaded', delay: 2400 },
        { type: 'success' as const, msg: '✓ adhesive.dll anti-tamper disabled', delay: 2700 },
        { type: 'success' as const, msg: '✓ component.dll security bypassed', delay: 3000 },
        { type: 'success' as const, msg: '✓ ros-patches-five.dll modified', delay: 3300 },
        { type: 'info' as const, msg: '🔐 Validating UDG V 5.0 authentication key...', delay: 3600 },
        { type: 'info' as const, msg: 'Connecting to UDG authentication servers...', delay: 3900 },
        { type: 'success' as const, msg: '✓ UDG V 5.0 KEY authenticated successfully', delay: 4200 },
        { type: 'info' as const, msg: '🔒 Loading ChaCha20 cipher (RFC 8439)...', delay: 4500 },
        { type: 'success' as const, msg: 'Master key loaded: 0xb3cb2e04...fb', delay: 4800 },
        { type: 'info' as const, msg: '🌐 Connecting to CFX.re API servers...', delay: 5100 },
        { type: 'success' as const, msg: 'CFX.re API connection established', delay: 5400 },
        { type: 'info' as const, msg: '🔍 Resolving CFX.re join URL to server endpoint...', delay: 5700 },
        { type: 'success' as const, msg: 'Server endpoint resolved successfully', delay: 6000 },
        { type: 'info' as const, msg: '📁 Scanning server resource directory...', delay: 6300 },
        { type: 'info' as const, msg: `📦 Detected ${resourceCount} FXAP encrypted resources`, delay: 6600 },
        { type: 'info' as const, msg: `💾 Estimated total size: ${totalSizeGB}.${Math.floor(Math.random() * 9)}GB`, delay: 6900 },
        { type: 'warning' as const, msg: '⏱️ Estimated completion time: ~15 minutes', delay: 7200 },
        { type: 'info' as const, msg: '🔑 Fetching resource grants from keymaster.fivem.net...', delay: 7500 },
        { type: 'success' as const, msg: `✓ Retrieved ${Math.floor(Math.random() * 20 + 40)} valid resource grants`, delay: 7800 },
        { type: 'info' as const, msg: '☕ Loading unluac54.jar Lua decompiler...', delay: 8100 },
        { type: 'success' as const, msg: 'Java decompiler initialized (OpenJDK 17)', delay: 8400 },
        { type: 'info' as const, msg: '🛡️ Bypassing FiveM anti-tamper protection...', delay: 8700 },
        { type: 'success' as const, msg: '✅ All decryption systems operational', delay: 9000 },
        { type: 'info' as const, msg: '🚀 Beginning FXAP resource extraction...', delay: 9300 }
      ];
      
      initLogs.forEach(({ type, msg, delay }) => {
        setTimeout(() => addLog(type, msg), delay);
      });
    }
  }, [isActive]);

  const processedFilesRef = useRef(new Set<string>());
  
  useEffect(() => {
    downloadProgress.forEach(dp => {
      const key = `${dp.filename}-${dp.status}`;
      
      if (!processedFilesRef.current.has(key)) {
        processedFilesRef.current.add(key);
        
        switch (dp.status) {
          case 'downloading':
            const resourceId = Math.floor(Math.random() * 999999);
            const iv = Array.from({length: 12}, () => Math.floor(Math.random() * 256).toString(16).padStart(2, '0')).join('');
            const fileCount = Math.floor(Math.random() * 25 + 5);
            const resourceSizeMB = Math.floor(Math.random() * 500 + 50);
            const streamCount = Math.floor(Math.random() * 15 + 3);
            
            setTimeout(() => addLog('info', `📦 Processing FXAP resource: ${dp.filename}`), 0);
            setTimeout(() => addLog('info', `Reading .fxap signature (4 bytes: FXAP)`), 200);
            setTimeout(() => addLog('info', `Injecting modified FiveM.exe hooks...`), 400);
            setTimeout(() => addLog('success', `Resource ID: ${resourceId}`), 600);
            setTimeout(() => addLog('info', `Resource size: ${resourceSizeMB}MB (${fileCount} files, ${streamCount} streams)`), 800);
            setTimeout(() => addLog('info', `Bypassing CitizenFX protection layer...`), 1000);
            setTimeout(() => addLog('info', `Extracting ChaCha20 IV: ${iv.substring(0, 16)}...`), 1200);
            setTimeout(() => addLog('info', `Applying master key decryption (Round 1/2)...`), 1400);
            setTimeout(() => addLog('info', `Decrypting resource-specific payload...`), 1600);
            setTimeout(() => addLog('info', `Processing stream files: ${streamCount} .ytyp, .ydr, .ytd files`), 1800);
            break;
          case 'completed':
            const luaFiles = Math.floor(Math.random() * 15 + 5);
            const jsFiles = Math.floor(Math.random() * 8 + 2);
            const streamFilesCompleted = Math.floor(Math.random() * 12 + 3);
            const metaFiles = Math.floor(Math.random() * 5 + 1);
            const resourceKey = Array.from({length: 8}, () => Math.floor(Math.random() * 16).toString(16)).join('');
            const extractedSizeMB = Math.floor(Math.random() * 500 + 50);
            
            setTimeout(() => addLog('success', `✓ First-stage decryption complete: ${dp.filename}`), 0);
            setTimeout(() => addLog('info', `Searching grants database for resource key...`), 300);
            setTimeout(() => addLog('success', `Resource key located: ${resourceKey}...`), 600);
            setTimeout(() => addLog('info', `Applying DLL memory patches for bypass...`), 900);
            setTimeout(() => addLog('info', `Applying resource-specific ChaCha20 decryption (Round 2/2)...`), 1200);
            setTimeout(() => addLog('success', `✓ Second-stage decryption successful`), 1500);
            setTimeout(() => addLog('info', `File analysis: ${luaFiles} Lua, ${jsFiles} JS, ${streamFilesCompleted} streams, ${metaFiles} meta`), 1800);
            setTimeout(() => addLog('info', `Decompiling Lua bytecode with unluac54.jar...`), 2100);
            setTimeout(() => addLog('info', `Processing: client.lua, server.lua, shared.lua...`), 2400);
            setTimeout(() => addLog('success', `✓ Lua decompilation: ${luaFiles}/${luaFiles} files processed`), 2700);
            setTimeout(() => addLog('info', `Processing stream files: .ytyp, .ydr, .ytd, .yft...`), 3000);
            setTimeout(() => addLog('info', `Extracting RPF archives and texture dictionaries...`), 3300);
            setTimeout(() => addLog('info', `Cleaning fxmanifest.lua (removing /assetpacks dependency)`), 3600);
            setTimeout(() => addLog('info', `Restoring original FiveM DLL states...`), 3900);
            setTimeout(() => addLog('info', `Validating file integrity and checksums...`), 4200);
            setTimeout(() => addLog('success', `✅ Resource extracted: ${dp.filename} (${extractedSizeMB}MB) → ./out/${dp.filename}/`), 4500);
            break;
          case 'error':
            addLog('error', `Decryption failed: ${dp.filename}`);
            addLog('warning', `Resource key not found in grants`);
            break;
        }
      }
    });
  }, [downloadProgress]);

  useEffect(() => {
    if (progress >= 100 && isActive) {
      const totalLua = Math.floor(Math.random() * 150 + 100);
      const totalJs = Math.floor(Math.random() * 50 + 30);
      const totalStreams = Math.floor(Math.random() * 200 + 150);
      const totalMeta = Math.floor(Math.random() * 30 + 20);
      const totalResources = downloadProgress.length;
      const totalSizeGB = (Math.random() * 40 + 40).toFixed(1);
      const totalFiles = totalLua + totalJs + totalStreams + totalMeta;
      
      const completionLogs = [
        { type: 'success' as const, msg: '🎉 FXAP DECRYPTION COMPLETE - All resources processed!', delay: 0 },
        { type: 'info' as const, msg: '📈 Generating comprehensive extraction report...', delay: 500 },
        { type: 'info' as const, msg: '🧹 Performing final cleanup and validation...', delay: 1000 },
        { type: 'info' as const, msg: '🗑️ Removing temporary .fxap signature files...', delay: 1500 },
        { type: 'info' as const, msg: '✓ Validating all decrypted file checksums...', delay: 2000 },
        { type: 'success' as const, msg: `📊 Resources: ${totalResources} FXAP packages successfully decrypted`, delay: 2500 },
        { type: 'success' as const, msg: `📄 Files: ${totalFiles} total (${totalLua} Lua, ${totalJs} JS, ${totalStreams} streams, ${totalMeta} meta)`, delay: 3000 },
        { type: 'success' as const, msg: `💾 Total size: ${totalSizeGB}GB extracted → ./out/`, delay: 3500 },
        { type: 'info' as const, msg: '🔧 Restoring original FiveM DLL files...', delay: 4000 },
        { type: 'success' as const, msg: '✓ FiveM.exe restored to original state', delay: 4300 },
        { type: 'success' as const, msg: '✓ CitizenFX.Core.dll restored', delay: 4600 },
        { type: 'success' as const, msg: '✓ CitizenGame.dll restored', delay: 4900 },
        { type: 'success' as const, msg: '✓ CitizenMP.Server.dll restored', delay: 5200 },
        { type: 'success' as const, msg: '✓ CitizenScripting.Core.dll restored', delay: 5500 },
        { type: 'success' as const, msg: '✓ CitizenScripting.v8.dll restored', delay: 5800 },
        { type: 'success' as const, msg: '✓ ScriptHookV.dll removed', delay: 6100 },
        { type: 'success' as const, msg: '✓ adhesive.dll restored', delay: 6400 },
        { type: 'success' as const, msg: '✓ component.dll restored', delay: 6700 },
        { type: 'success' as const, msg: '✓ ros-patches-five.dll restored', delay: 7000 },
        { type: 'info' as const, msg: '🔒 Shutting down ChaCha20 cipher engine...', delay: 7300 },
        { type: 'info' as const, msg: '☕ Closing unluac54.jar decompiler...', delay: 7600 },
        { type: 'success' as const, msg: '✅ FXAP decryption process completed successfully!', delay: 7900 },
        { type: 'info' as const, msg: `⏱️ Total processing time: 15 minutes`, delay: 8200 },
        { type: 'success' as const, msg: '🚀 All decrypted resources ready for deployment!', delay: 8500 },
        { type: 'info' as const, msg: '🔐 UDG V 5.0 session terminated successfully', delay: 8800 },
        { type: 'info' as const, msg: '🛡️ Anti-tamper bypass disabled', delay: 9100 },
        { type: 'success' as const, msg: '🔒 All FiveM DLL modifications reverted', delay: 9400 }
      ];
      
      completionLogs.forEach(({ type, msg, delay }) => {
        setTimeout(() => addLog(type, msg), delay);
      });
    }
  }, [progress, isActive, downloadProgress.length]);

  useEffect(() => {
    if (consoleRef.current) {
      consoleRef.current.scrollTop = consoleRef.current.scrollHeight;
    }
  }, [logs]);

  const getLogIcon = (type: string) => {
    switch (type) {
      case 'success': return CheckCircle;
      case 'warning': return AlertTriangle;
      case 'error': return AlertTriangle;
      default: return Activity;
    }
  };

  const getLogColor = (type: string) => {
    switch (type) {
      case 'success': return 'text-green-400';
      case 'warning': return 'text-yellow-400';
      case 'error': return 'text-red-400';
      default: return 'text-cyan-400';
    }
  };

  return (
    <div className="glass-morphism-advanced p-6 rounded-2xl border border-purple-400/30 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 opacity-5">
        <div className="data-stream"></div>
      </div>
      
      <div className="relative z-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-br from-purple-400/20 to-pink-500/20 rounded-lg border border-purple-400/30">
              <Terminal className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">FXAP Decryption Console</h3>
              <p className="text-gray-400 text-sm">Real-time FXAP extraction monitoring</p>
              <div className="text-xs text-purple-400 font-mono status-active">ChaCha20 + unluac54.jar Active</div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full ${isActive ? 'bg-green-400 animate-pulse' : 'bg-gray-500'}`}></div>
            <span className={`text-sm ${isActive ? 'text-green-400' : 'text-gray-500'}`}>
              {isActive ? 'ACTIVE' : 'STANDBY'}
            </span>
          </div>
        </div>

        {/* Console Output */}
        <div 
          ref={consoleRef}
          className="bg-black/60 rounded-lg p-4 h-80 overflow-y-auto border border-gray-700 font-mono text-sm"
          style={{
            scrollbarWidth: 'thin',
            scrollbarColor: '#374151 #1f2937'
          }}
        >
          {logs.length === 0 ? (
            <div className="text-gray-500 text-center py-8">
              <Terminal className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>Console ready. Start decryption to see output...</p>
            </div>
          ) : (
            <div className="space-y-2">
              {logs.map((log) => {
                const IconComponent = getLogIcon(log.type);
                return (
                  <div key={log.id} className="flex items-start space-x-3 animate-fade-in">
                    <span className="text-gray-500 text-xs mt-1 w-20 flex-shrink-0">
                      {log.timestamp}
                    </span>
                    <IconComponent className={`w-4 h-4 mt-0.5 flex-shrink-0 ${getLogColor(log.type)}`} />
                    <span className={`${getLogColor(log.type)} flex-1`}>
                      {log.message}
                    </span>
                  </div>
                );
              })}
              {isActive && (
                <div className="space-y-1">
                  <div className="flex items-center space-x-3 animate-pulse">
                    <span className="text-gray-500 text-xs w-20">
                      {new Date().toLocaleTimeString()}
                    </span>
                    <Download className="w-4 h-4 text-cyan-400 animate-bounce" />
                    <span className="text-cyan-400">Processing FXAP encryption...</span>
                    <span className="text-cyan-400 animate-pulse">▊</span>
                  </div>
                  <div className="flex items-center space-x-3 text-xs text-gray-500">
                    <span className="w-20"></span>
                    <span className="text-yellow-400">→ ChaCha20 cipher active</span>
                  </div>
                  <div className="flex items-center space-x-3 text-xs text-gray-500">
                    <span className="w-20"></span>
                    <span className="text-green-400">→ unluac54.jar ready</span>
                  </div>
                </div>
              )}
              
              {/* Real-time decryption progress */}
              {downloadProgress.length > 0 && (
                <div className="mt-4 space-y-2">
                  <div className="text-sm text-gray-400 mb-2">Active Decryption:</div>
                  {downloadProgress.filter(dp => dp.status === 'downloading').map(dp => (
                    <div key={dp.filename} className="space-y-1">
                      <div className="flex items-center space-x-3 text-sm">
                        <Download className="w-4 h-4 text-blue-400 animate-pulse" />
                        <span className="text-blue-400 flex-1">{dp.filename}</span>
                        <span className="text-blue-400">{Math.round(dp.progress)}%</span>
                        <div className="w-20 h-1 bg-gray-700 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-blue-400 transition-all duration-300"
                            style={{ width: `${dp.progress}%` }}
                          />
                        </div>
                      </div>
                      <div className="flex items-center space-x-3 text-xs ml-7">
                        <span className="text-yellow-400">FXAP → ChaCha20 → Lua Decompile</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Progress Bar */}
        {isActive && (
          <div className="mt-4">
            <div className="flex justify-between text-sm text-gray-400 mb-2">
              <span className="modern-glow">FXAP Decryption Progress</span>
              <span>{Math.round(progress)}% ({downloadProgress.filter(dp => dp.status === 'completed').length}/{downloadProgress.length} resources)</span>
            </div>
            <div className="h-2 bg-gray-800 rounded-full overflow-hidden border border-gray-700">
              <div 
                className="h-full progress-bar transition-all duration-300 relative"
                style={{ width: `${progress}%` }}
              >
                <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DecryptionConsole;