import React, { useState, useEffect } from 'react';
import { Shield, Zap, Lock, Unlock } from 'lucide-react';

interface DecryptionEffectProps {
  progress: number;
  onComplete: () => void;
}

const DecryptionEffect: React.FC<DecryptionEffectProps> = ({ progress, onComplete }) => {
  const [phase, setPhase] = useState(0);
  const [text, setText] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);

  const phases = React.useMemo(() => [
    'INITIALIZING FXAP DECRYPTION ENGINE...',
    'LOADING CHACHA20 CIPHER KEYS...',
    'BYPASSING FXAP SECURITY PROTOCOLS...',
    'EXTRACTING ENCRYPTED RESOURCE DATA...',
    'DECOMPILING LUA BYTECODE...',
    'FXAP DECRYPTION COMPLETE!'
  ], []);

  useEffect(() => {
    const newPhase = Math.floor((progress / 100) * (phases.length - 1));
    if (newPhase !== phase && newPhase < phases.length) {
      setPhase(newPhase);
    }
  }, [progress, phase, phases.length]);
  
  useEffect(() => {
    if (progress >= 100 && !showSuccess) {
      setShowSuccess(true);
      const timeoutId = setTimeout(() => {
        onComplete();
      }, 3000);
      return () => clearTimeout(timeoutId);
    }
  }, [progress, showSuccess, onComplete]);

  useEffect(() => {
    const currentPhrase = phases[phase];
    let index = 0;
    setText('');
    
    const typeInterval = setInterval(() => {
      if (index < currentPhrase.length) {
        setText(currentPhrase.substring(0, index + 1));
        index++;
      } else {
        clearInterval(typeInterval);
      }
    }, 30);

    return () => clearInterval(typeInterval);
  }, [phase]);

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-lg flex items-center justify-center z-50 overflow-hidden">
      {/* Advanced matrix rain effect */}
      <div className="absolute inset-0 opacity-20">
        <div className="matrix-rain-advanced"></div>
      </div>
      
      {/* Scanning lines */}
      <div className="absolute inset-0 opacity-30">
        <div className="scanning-lines-advanced"></div>
      </div>
      
      <div className="text-center space-y-12 max-w-4xl mx-auto px-8 relative z-10">
        {/* Main decryption visual */}
        <div className="relative">
          <div className="absolute -inset-12 bg-gradient-to-r from-cyan-400/20 via-blue-500/20 via-purple-500/20 to-pink-500/20 rounded-full blur-3xl animate-pulse-slow"></div>
          
          <div className="relative flex items-center justify-center space-x-8">
            <div className="relative">
              <Shield className="w-40 h-40 text-cyan-400 animate-spin-slow" />
              <div className="absolute inset-0 flex items-center justify-center">
                {showSuccess ? (
                  <Unlock className="w-20 h-20 text-green-400 animate-bounce" />
                ) : (
                  <Lock className="w-20 h-20 text-red-400 animate-pulse" />
                )}
              </div>
            </div>
            
            <div className="flex flex-col space-y-4">
              <Zap className="w-24 h-24 text-yellow-400 animate-bounce mx-auto" />
              <div className="text-6xl font-mono text-green-400 animate-pulse">
                {Math.round(progress)}%
              </div>
            </div>
          </div>
        </div>
        
        {/* Status text */}
        <div className="space-y-6">
          {showSuccess ? (
            <div className="space-y-4">
              <h1 className="text-8xl font-black holographic-effect neon-glow animate-pulse">
                SUCCESS
              </h1>
              <p className="text-2xl text-green-400 tracking-widest">
                ALL FXAP RESOURCES SUCCESSFULLY DECRYPTED
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <h1 className="text-7xl font-black holographic-effect glitch-animation neon-glow">
                DECRYPTING FXAP
              </h1>
              
              <div className="h-16 flex items-center justify-center">
                <p className="text-green-400 font-mono text-2xl tracking-wider terminal-cursor bg-black/50 px-8 py-4 rounded-xl border border-green-400/30 chacha20-effect">
                  {text}
                </p>
              </div>
            </div>
          )}
        </div>
        
        {/* Advanced progress visualization */}
        <div className="space-y-8">
          <div className="w-full max-w-2xl mx-auto">
            <div className="h-6 bg-gray-800 rounded-full overflow-hidden border-2 border-gray-700 relative">
              <div 
                className="h-full fxap-loading-bar transition-all duration-500 relative"
                style={{ width: `${progress}%` }}
              >
                <div className="absolute inset-0 bg-white/30 animate-pulse"></div>
                <div className="absolute right-0 top-0 h-full w-2 bg-white animate-pulse quantum-particle"></div>
              </div>
            </div>
          </div>
          
          {/* Phase indicators */}
          <div className="flex justify-center space-x-6">
            {phases.slice(0, -1).map((_, i) => (
              <div key={i} className="text-center">
                <div className={`w-4 h-4 rounded-full mx-auto mb-2 transition-all duration-500 ${
                  i <= phase ? 'bg-green-400 animate-pulse shadow-lg shadow-green-400/50' : 'bg-gray-600'
                }`}></div>
                <span className={`text-xs transition-colors duration-500 ${
                  i <= phase ? 'text-green-400' : 'text-gray-500'
                }`}>
                  PHASE {i + 1}
                </span>
              </div>
            ))}
          </div>
        </div>
        
        {/* Data stream visualization */}
        <div className="grid grid-cols-3 gap-8 text-sm font-mono">
          <div className="space-y-2">
            <div className="text-cyan-400 chacha20-effect">CHACHA20 CIPHER</div>
            <div className="text-green-400 animate-pulse neon-glow">ACTIVE</div>
          </div>
          <div className="space-y-2">
            <div className="text-purple-400 fxap-decrypt-animation">FXAP PARSER</div>
            <div className="text-green-400 animate-pulse neon-glow">PROCESSING</div>
          </div>
          <div className="space-y-2">
            <div className="text-yellow-400 lua-decompile-effect">UNLUAC54.JAR</div>
            <div className="text-green-400 animate-pulse neon-glow">OPERATIONAL</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DecryptionEffect;