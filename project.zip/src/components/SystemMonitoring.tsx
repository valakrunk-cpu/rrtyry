import React, { useState, useEffect } from 'react';
import { AlertTriangle, CheckCircle, Clock, Database } from 'lucide-react';

interface SystemMonitoringProps {
  compact?: boolean;
}

const SystemMonitoring: React.FC<SystemMonitoringProps> = ({ compact = false }) => {
  const [logs, setLogs] = useState([
    { id: '1', type: 'info', message: 'Server started successfully', timestamp: '14:32:15', status: 'success' },
    { id: '2', type: 'warning', message: 'High CPU usage detected', timestamp: '14:31:42', status: 'warning' },
    { id: '3', type: 'info', message: 'Player connected: CyberNinja47', timestamp: '14:30:18', status: 'info' },
    { id: '4', type: 'error', message: 'Resource failed to load: custom_cars', timestamp: '14:29:33', status: 'error' },
    { id: '5', type: 'info', message: 'Database backup completed', timestamp: '14:28:12', status: 'success' },
  ]);

  const getLogIcon = (type: string) => {
    switch (type) {
      case 'error': return AlertTriangle;
      case 'warning': return AlertTriangle;
      case 'success': return CheckCircle;
      default: return Database;
    }
  };

  const getLogColor = (status: string) => {
    switch (status) {
      case 'error': return 'text-red-400';
      case 'warning': return 'text-yellow-400';
      case 'success': return 'text-green-400';
      default: return 'text-blue-400';
    }
  };

  const displayedLogs = compact ? logs.slice(0, 5) : logs;

  return (
    <div className="glass-morphism p-6 rounded-xl border border-gray-700">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-semibold text-white">
          {compact ? 'System Status' : 'System Monitoring'}
        </h3>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span className="text-sm text-green-400">Active</span>
        </div>
      </div>

      {!compact && (
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-400">99.8%</div>
            <div className="text-xs text-gray-400">Uptime</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-400">42ms</div>
            <div className="text-xs text-gray-400">Avg Response</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-400">156</div>
            <div className="text-xs text-gray-400">Requests/min</div>
          </div>
        </div>
      )}

      <div className="space-y-2">
        <h4 className="text-sm font-medium text-gray-400 mb-3">Recent Activity</h4>
        {displayedLogs.map((log, index) => {
          const IconComponent = getLogIcon(log.type);
          return (
            <div
              key={log.id}
              className="flex items-center space-x-3 p-2 rounded-lg bg-gray-800/30 hover:bg-gray-800/50 transition-colors"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <IconComponent className={`w-4 h-4 ${getLogColor(log.status)}`} />
              <div className="flex-1 min-w-0">
                <p className="text-sm text-white truncate">{log.message}</p>
              </div>
              <div className="flex items-center text-xs text-gray-400">
                <Clock className="w-3 h-3 mr-1" />
                {log.timestamp}
              </div>
            </div>
          );
        })}
      </div>

      {compact && (
        <div className="mt-4 text-center">
          <button className="text-cyan-400 hover:text-cyan-300 text-sm">
            View Full Logs →
          </button>
        </div>
      )}
    </div>
  );
};

export default SystemMonitoring;