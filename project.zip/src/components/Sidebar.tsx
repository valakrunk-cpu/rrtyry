import React from 'react';
import { 
  Home, 
  Database, 
  Users, 
  Activity, 
  Settings, 
  Terminal, 
  Shield, 
  Zap,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
  activePanel: string;
  onPanelChange: (panel: string) => void;
}

const menuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: Home },
  { id: 'resources', label: 'Resources', icon: Database },
  { id: 'players', label: 'Players', icon: Users },
  { id: 'monitoring', label: 'Monitoring', icon: Activity },
  { id: 'console', label: 'Console', icon: Terminal },
  { id: 'security', label: 'Security', icon: Shield },
  { id: 'performance', label: 'Performance', icon: Zap },
  { id: 'settings', label: 'Settings', icon: Settings },
];

const Sidebar: React.FC<SidebarProps> = ({ collapsed, onToggle, activePanel, onPanelChange }) => {
  return (
    <aside className={`${collapsed ? 'w-16' : 'w-64'} transition-all duration-300 ease-in-out bg-black/60 backdrop-blur-md border-r border-cyan-400/20 relative`}>
      {/* Toggle button */}
      <button
        onClick={onToggle}
        className="absolute -right-3 top-6 w-6 h-6 bg-gray-800 rounded-full border border-cyan-400/30 flex items-center justify-center hover:bg-cyan-400/10 transition-all duration-300 z-20"
      >
        {collapsed ? (
          <ChevronRight className="w-3 h-3 text-cyan-400" />
        ) : (
          <ChevronLeft className="w-3 h-3 text-cyan-400" />
        )}
      </button>

      {/* Menu items */}
      <nav className="mt-8 px-3">
        <div className="space-y-2">
          {menuItems.map((item) => {
            const IconComponent = item.icon;
            const isActive = activePanel === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => onPanelChange(item.id)}
                className={`w-full flex items-center ${collapsed ? 'justify-center px-2' : 'px-4'} py-3 rounded-lg transition-all duration-300 relative group ${
                  isActive
                    ? 'bg-cyan-400/20 border border-cyan-400/50 text-cyan-400'
                    : 'hover:bg-gray-800/50 text-gray-400 hover:text-cyan-400'
                }`}
              >
                {/* Active indicator */}
                {isActive && (
                  <div className="absolute left-0 w-1 h-6 bg-gradient-to-b from-cyan-400 to-blue-400 rounded-r-full neon-glow"></div>
                )}
                
                <IconComponent className={`w-5 h-5 ${isActive ? 'text-cyan-400' : 'text-gray-400 group-hover:text-cyan-400'} transition-colors`} />
                
                {!collapsed && (
                  <span className={`ml-3 font-medium ${isActive ? 'text-cyan-400' : 'text-gray-400 group-hover:text-cyan-400'} transition-colors`}>
                    {item.label}
                  </span>
                )}
                
                {/* Tooltip for collapsed state */}
                {collapsed && (
                  <div className="absolute left-14 bg-gray-800 text-white px-2 py-1 rounded text-sm opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-30 border border-cyan-400/30">
                    {item.label}
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </nav>

      {/* Server info at bottom */}
      {!collapsed && (
        <div className="absolute bottom-4 left-0 right-0 px-3">
          <div className="bg-gray-800/50 rounded-lg p-3 border border-gray-700">
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-400">Server Load</span>
              <span className="text-green-400">Normal</span>
            </div>
            <div className="mt-2 bg-gray-700 rounded-full h-2">
              <div className="bg-gradient-to-r from-green-400 to-cyan-400 h-2 rounded-full w-3/4"></div>
            </div>
          </div>
        </div>
      )}
    </aside>
  );
};

export default Sidebar;