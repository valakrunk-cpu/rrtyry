import React, { useState, useEffect } from 'react';
import { Shield, Zap, Activity, Settings, User, Power } from 'lucide-react';

const Header: React.FC = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [systemStatus, setSystemStatus] = useState<'operational' | 'decrypting' | 'standby'>('operational');

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <header className="h-20 bg-black/60 backdrop-blur-xl border-b border-cyan-400/20 relative overflow-hidden">
      {/* Animated background lines */}
      <div className="absolute inset-0 opacity-10">
        <div className="scanning-lines"></div>
      </div>
      
      <div className="relative z-10 h-full flex items-center justify-between px-8">
        {/* Logo section with enhanced effects */}
        <div className="flex items-center space-x-6">
          <div className="relative group">
            <div className="absolute -inset-3 bg-gradient-to-r from-cyan-400/30 via-blue-500/30 to-purple-500/30 rounded-xl blur-lg group-hover:blur-xl transition-all duration-300"></div>
            <div className="relative bg-gradient-to-br from-gray-900 to-black p-4 rounded-xl border border-cyan-400/50 group-hover:border-cyan-400/80 transition-all duration-300">
              <div className="flex items-center space-x-2">
                <Shield className="w-8 h-8 text-cyan-400" />
                <Zap className="w-6 h-6 text-yellow-400 animate-pulse" />
              </div>
            </div>
          </div>
          
          <div className="space-y-1">
            <h1 className="text-3xl font-black bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
              UDG V 5.0
            </h1>
            <p className="text-sm text-gray-400 tracking-[0.2em] font-light">
              FXAP DECRYPTION SYSTEM
            </p>
            <div className="flex items-center space-x-2 text-xs text-gray-500">
              <div className="w-1 h-1 bg-green-400 rounded-full animate-pulse"></div>
              <span>CHACHA20 + UNLUAC54.JAR</span>
            </div>
          </div>
        </div>

        {/* Center status display */}
        <div className="flex items-center space-x-8">
          <div className="text-center">
            <div className="text-2xl font-mono text-cyan-400 modern-glow">
              {currentTime.toLocaleTimeString('en-US', { hour12: false })}
            </div>
            <div className="text-xs text-gray-500 tracking-wider">
              SYSTEM TIME
            </div>
          </div>
          
          <div className="h-12 w-px bg-gradient-to-b from-transparent via-gray-600 to-transparent"></div>
          
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-1">
              <div className={`w-3 h-3 rounded-full animate-pulse ${
                systemStatus === 'operational' ? 'bg-green-400' : 
                systemStatus === 'decrypting' ? 'bg-yellow-400' : 'bg-blue-400'
              }`}></div>
              <span className="text-sm font-semibold text-white uppercase">
                {systemStatus}
              </span>
            </div>
            <div className="text-xs text-gray-500 tracking-wider">
              FXAP STATUS
            </div>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center space-x-4">
          <button className="group relative p-3 rounded-xl bg-gray-800/50 hover:bg-cyan-400/10 border border-gray-700 hover:border-cyan-400/50 transition-all duration-300">
            <Activity className="w-5 h-5 text-gray-400 group-hover:text-cyan-400 transition-colors" />
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
          </button>
          
          <button className="group relative p-3 rounded-xl bg-gray-800/50 hover:bg-cyan-400/10 border border-gray-700 hover:border-cyan-400/50 transition-all duration-300">
            <Settings className="w-5 h-5 text-gray-400 group-hover:text-cyan-400 transition-colors" />
          </button>
          
          <button className="group relative p-3 rounded-xl bg-gray-800/50 hover:bg-cyan-400/10 border border-gray-700 hover:border-cyan-400/50 transition-all duration-300">
            <User className="w-5 h-5 text-gray-400 group-hover:text-cyan-400 transition-colors" />
          </button>
          
          <div className="h-8 w-px bg-gradient-to-b from-transparent via-gray-600 to-transparent"></div>
          
          <button className="group relative p-3 rounded-xl bg-red-900/20 hover:bg-red-500/20 border border-red-800/50 hover:border-red-500/50 transition-all duration-300">
            <Power className="w-5 h-5 text-red-400 group-hover:text-red-300 transition-colors" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;