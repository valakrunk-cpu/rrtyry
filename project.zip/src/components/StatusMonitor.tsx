import React, { useState, useEffect } from 'react';
import { Monitor, Cpu, HardDrive, Network, Database, Shield } from 'lucide-react';
import { ServerConfig } from '../utils/fivemDownloader';

interface StatusMonitorProps {
  config: ServerConfig;
  isDecrypting: boolean;
  progress: number;
}

const StatusMonitor: React.FC<StatusMonitorProps> = ({ config, isDecrypting, progress }) => {
  const [systemStats, setSystemStats] = useState({
    cpu: 23,
    memory: 45,
    network: 67,
    disk: 34
  });

  const [extractedFiles, setExtractedFiles] = useState(0);
  const [totalFiles, setTotalFiles] = useState(Math.floor(Math.random() * 20 + 25));
  const [totalSizeGB, setTotalSizeGB] = useState(Math.floor(Math.random() * 40 + 40));

  useEffect(() => {
    if (isDecrypting) {
      setExtractedFiles(Math.floor((progress / 100) * totalFiles));
    }
  }, [isDecrypting, progress, totalFiles]);
  
  useEffect(() => {
    // Regenerate totals when decryption starts
    if (isDecrypting && progress === 0) {
      setTotalFiles(Math.floor(Math.random() * 20 + 25));
      setTotalSizeGB(Math.floor(Math.random() * 40 + 40));
    }
  }, [isDecrypting, progress]);

  useEffect(() => {
    const interval = setInterval(() => {
      setSystemStats(prev => ({
        cpu: Math.max(10, Math.min(90, prev.cpu + (Math.random() - 0.5) * 10)),
        memory: Math.max(20, Math.min(80, prev.memory + (Math.random() - 0.5) * 5)),
        network: Math.max(5, Math.min(95, prev.network + (Math.random() - 0.5) * 15)),
        disk: Math.max(15, Math.min(60, prev.disk + (Math.random() - 0.5) * 3))
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const getColorClasses = (color: string, isActive: boolean) => {
    const colorMap = {
      blue: {
        bg: isActive ? 'bg-blue-400/10' : 'bg-gray-800/30',
        border: isActive ? 'border-blue-400/50' : 'border-gray-700',
        text: isActive ? 'text-blue-400' : 'text-gray-400',
        bar: isActive ? 'bg-blue-400' : 'bg-gray-500'
      },
      purple: {
        bg: isActive ? 'bg-purple-400/10' : 'bg-gray-800/30',
        border: isActive ? 'border-purple-400/50' : 'border-gray-700',
        text: isActive ? 'text-purple-400' : 'text-gray-400',
        bar: isActive ? 'bg-purple-400' : 'bg-gray-500'
      },
      cyan: {
        bg: isActive ? 'bg-cyan-400/10' : 'bg-gray-800/30',
        border: isActive ? 'border-cyan-400/50' : 'border-gray-700',
        text: isActive ? 'text-cyan-400' : 'text-gray-400',
        bar: isActive ? 'bg-cyan-400' : 'bg-gray-500'
      },
      green: {
        bg: isActive ? 'bg-green-400/10' : 'bg-gray-800/30',
        border: isActive ? 'border-green-400/50' : 'border-gray-700',
        text: isActive ? 'text-green-400' : 'text-gray-400',
        bar: isActive ? 'bg-green-400' : 'bg-gray-500'
      }
    };
    return colorMap[color as keyof typeof colorMap] || colorMap.blue;
  };

  const StatCard = ({ icon: Icon, label, value, unit, color, isActive = false }: {
    icon: React.ComponentType<any>;
    label: string;
    value: number | string;
    unit?: string;
    color: 'blue' | 'purple' | 'cyan' | 'green';
    isActive?: boolean;
  }) => (
    <div className={`p-4 rounded-xl border transition-all duration-300 hover:border-gray-600 ${
      getColorClasses(color, isActive).bg
    } ${
      getColorClasses(color, isActive).border
    }`}>
      <div className="flex items-center justify-between mb-3">
        <Icon className={`w-5 h-5 ${getColorClasses(color, isActive).text}`} />
        <span className={`text-lg font-bold ${isActive ? getColorClasses(color, isActive).text : 'text-white'}`}>
          {value}{unit}
        </span>
      </div>
      <p className="text-sm text-gray-400">{label}</p>
      {typeof value === 'number' && (
        <div className="mt-2 bg-gray-700 rounded-full h-1.5">
          <div 
            className={`h-1.5 rounded-full transition-all duration-1000 ${getColorClasses(color, isActive).bar}`}
            style={{ width: `${value}%` }}
          ></div>
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-6">
      {/* System Status */}
      <div className="glass-morphism-advanced p-6 rounded-2xl border border-green-400/30 relative overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <div className="pulse-grid"></div>
        </div>
        
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-gradient-to-br from-green-400/20 to-cyan-500/20 rounded-lg border border-green-400/30">
                <Monitor className="w-5 h-5 text-green-400" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white holographic-effect">System Monitor</h3>
                <p className="text-gray-400 text-sm">Real-time performance metrics</p>
                <div className="text-xs text-green-400 font-mono chacha20-effect">FXAP Engine Active</div>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-sm text-green-400">OPTIMAL</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <StatCard 
              icon={Cpu} 
              label="CPU Usage" 
              value={systemStats.cpu} 
              unit="%" 
              color="blue"
              isActive={isDecrypting}
            />
            <StatCard 
              icon={Database} 
              label="Memory" 
              value={systemStats.memory} 
              unit="%" 
              color="purple"
              isActive={isDecrypting}
            />
            <StatCard 
              icon={Network} 
              label="Network I/O" 
              value={systemStats.network} 
              unit="%" 
              color="cyan"
              isActive={isDecrypting}
            />
            <StatCard 
              icon={HardDrive} 
              label="Disk Usage" 
              value={systemStats.disk} 
              unit="%" 
              color="green"
            />
          </div>
        </div>
      </div>

      {/* Target Server Info */}
      <div className="glass-morphism-advanced p-6 rounded-2xl border border-blue-400/30">
        <div className="flex items-center space-x-3 mb-6">
          <div className="p-2 bg-gradient-to-br from-blue-400/20 to-purple-500/20 rounded-lg border border-blue-400/30">
            <Shield className="w-5 h-5 text-blue-400" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white holographic-effect">Target Server</h3>
            <p className="text-gray-400 text-sm">Connection details</p>
            <div className="text-xs text-blue-400 font-mono lua-decompile-effect">FXAP Resources Detected</div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex justify-between items-center p-3 bg-gray-800/30 rounded-lg border border-gray-700">
            <span className="text-gray-400">Address</span>
            <span className="text-white font-mono">{config.ip}:{config.port}</span>
          </div>
          
          {config.cfxUrl && (
            <div className="flex justify-between items-center p-3 bg-gray-800/30 rounded-lg border border-gray-700">
              <span className="text-gray-400">CFX URL</span>
              <span className="text-white font-mono text-sm">{config.cfxUrl}</span>
            </div>
          )}
          
          <div className="flex justify-between items-center p-3 bg-gray-800/30 rounded-lg border border-gray-700">
            <span className="text-gray-400">Semaphore</span>
            <span className="text-cyan-400 font-mono">{config.streamSemaphore}</span>
          </div>
        </div>
      </div>

      {/* Extraction Progress */}
      <div className="glass-morphism-advanced p-6 rounded-2xl border border-purple-400/30">
        <div className="flex items-center space-x-3 mb-6">
          <div className="p-2 bg-gradient-to-br from-purple-400/20 to-pink-500/20 rounded-lg border border-purple-400/30">
            <Database className="w-5 h-5 text-purple-400" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white holographic-effect">Extraction Status</h3>
            <p className="text-gray-400 text-sm">File processing progress</p>
            <div className="text-xs text-purple-400 font-mono fxap-decrypt-animation">ChaCha20 + unluac54.jar</div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-gray-400">Resources Extracted</span>
            <span className="text-cyan-400 font-mono text-lg">
              {extractedFiles} / {totalFiles}
            </span>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-gray-400">Total Size</span>
            <span className="text-purple-400 font-mono text-lg">
              {totalSizeGB}.{Math.floor(Math.random() * 9)}GB
            </span>
          </div>
          
          <div className="bg-gray-800 rounded-full h-3 overflow-hidden border border-gray-700">
            <div 
              className="h-full bg-gradient-to-r from-purple-400 to-cyan-400 transition-all duration-500 relative"
              style={{ width: `${(extractedFiles / totalFiles) * 100}%` }}
            >
              <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="text-center p-2 bg-gray-800/30 rounded-lg border border-gray-700">
              <div className="text-green-400 font-mono text-lg neon-glow">{Math.round(progress)}%</div>
              <div className="text-gray-400">Complete</div>
            </div>
            <div className="text-center p-2 bg-gray-800/30 rounded-lg border border-gray-700">
              <div className="text-blue-400 font-mono text-lg">
                {isDecrypting ? 
                  Math.max(0, Math.round(15 - (progress / 100) * 15)) + 'm' : 
                  '15m'
                }
              </div>
              <div className="text-gray-400">ETA</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatusMonitor;