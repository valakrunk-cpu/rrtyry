import React, { useState, useEffect } from 'react';
import { Cpu, MemoryStick, HardDrive, Network, TrendingUp } from 'lucide-react';

const ServerStats: React.FC = () => {
  const [stats, setStats] = useState({
    cpu: 45,
    memory: 68,
    disk: 32,
    network: 23,
    uptime: '7d 14h 32m'
  });

  const [chartData, setChartData] = useState<number[]>([]);

  useEffect(() => {
    // Generate random chart data
    const data = Array.from({ length: 20 }, () => Math.random() * 100);
    setChartData(data);

    // Simulate real-time updates
    const interval = setInterval(() => {
      setStats(prev => ({
        ...prev,
        cpu: Math.max(0, Math.min(100, prev.cpu + (Math.random() - 0.5) * 10)),
        memory: Math.max(0, Math.min(100, prev.memory + (Math.random() - 0.5) * 5)),
        network: Math.max(0, Math.min(100, prev.network + (Math.random() - 0.5) * 15))
      }));

      setChartData(prev => [...prev.slice(1), Math.random() * 100]);
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const StatCard = ({ icon: Icon, label, value, unit, color }: {
    icon: any;
    label: string;
    value: number | string;
    unit?: string;
    color: string;
  }) => (
    <div className="glass-morphism p-4 rounded-xl border border-gray-700 hover:border-cyan-400/50 transition-all duration-300">
      <div className="flex items-center justify-between mb-3">
        <div className={`p-2 rounded-lg bg-${color}-400/20`}>
          <Icon className={`w-5 h-5 text-${color}-400`} />
        </div>
        <span className="text-2xl font-bold text-white">{value}{unit}</span>
      </div>
      <p className="text-sm text-gray-400">{label}</p>
      {typeof value === 'number' && (
        <div className="mt-2 bg-gray-800 rounded-full h-2">
          <div 
            className={`bg-gradient-to-r from-${color}-400 to-${color}-300 h-2 rounded-full transition-all duration-1000`}
            style={{ width: `${value}%` }}
          ></div>
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="glass-morphism p-6 rounded-xl border border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold text-white">System Performance</h3>
          <div className="flex items-center text-sm text-green-400">
            <TrendingUp className="w-4 h-4 mr-1" />
            Optimal
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <StatCard icon={Cpu} label="CPU Usage" value={stats.cpu} unit="%" color="blue" />
          <StatCard icon={MemoryStick} label="Memory" value={stats.memory} unit="%" color="purple" />
          <StatCard icon={HardDrive} label="Disk Usage" value={stats.disk} unit="%" color="green" />
          <StatCard icon={Network} label="Network I/O" value={stats.network} unit="%" color="yellow" />
        </div>

        {/* Real-time chart */}
        <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
          <h4 className="text-sm font-medium text-gray-400 mb-3">CPU Performance (Real-time)</h4>
          <div className="flex items-end justify-between h-16 space-x-1">
            {chartData.map((value, index) => (
              <div
                key={index}
                className="bg-gradient-to-t from-cyan-400 to-blue-400 rounded-t-sm transition-all duration-500 min-w-[8px]"
                style={{ height: `${value}%` }}
              ></div>
            ))}
          </div>
        </div>
      </div>

      <div className="glass-morphism p-6 rounded-xl border border-gray-700">
        <h3 className="text-xl font-semibold text-white mb-4">Server Information</h3>
        <div className="grid grid-cols-2 gap-6">
          <div>
            <p className="text-sm text-gray-400">Uptime</p>
            <p className="text-lg font-mono text-green-400">{stats.uptime}</p>
          </div>
          <div>
            <p className="text-sm text-gray-400">Version</p>
            <p className="text-lg font-mono text-cyan-400">5.0.3142</p>
          </div>
          <div>
            <p className="text-sm text-gray-400">Build</p>
            <p className="text-lg font-mono text-blue-400">2024.01.15</p>
          </div>
          <div>
            <p className="text-sm text-gray-400">License</p>
            <p className="text-lg font-mono text-purple-400">DECRYPTED</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServerStats;