import React, { useState } from 'react';
import { Search, Server, BarChart3, Users, Package, AlertCircle, CheckCircle } from 'lucide-react';
import { FiveMDownloader, ServerConfig } from '../utils/fivemDownloader';

interface ServerAnalyzerProps {
  config: ServerConfig;
  onAnalysisComplete?: (analysis: any) => void;
}

const ServerAnalyzer: React.FC<ServerAnalyzerProps> = ({ config, onAnalysisComplete }) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const analyzeServer = async () => {
    setIsAnalyzing(true);
    setError(null);
    
    try {
      const downloader = new FiveMDownloader(config);
      
      // Get server info and resources
      const serverInfo = await downloader.getServerInfo();
      const resources = await downloader.getResourcesList();
      
      console.log(`🔍 Analyzing server: ${serverInfo.hostname}`);
      console.log(`📊 Found ${resources.length} resources`);
      
      // Analyze resource types
      const resourceTypes: Record<string, number> = {};
      const commonResources: string[] = [];
      const customResources: string[] = [];
      
      resources.forEach(resource => {
        console.log(`📦 Analyzing resource: ${resource}`);
        
        // Categorize resources
        if (resource.startsWith('esx_') || resource.startsWith('qb-') || resource.startsWith('es_')) {
          commonResources.push(resource);
        } else {
          customResources.push(resource);
        }
        
        // Count resource types
        const prefix = resource.split('_')[0] + '_';
        resourceTypes[prefix] = (resourceTypes[prefix] || 0) + 1;
      });
      
      const result = {
        serverInfo: {
          Data: {
            hostname: serverInfo.hostname,
            clients: serverInfo.players,
            sv_maxclients: serverInfo.maxPlayers
          }
        },
        resourceAnalysis: {
          totalResources: resources.length,
          commonResources,
          customResources,
          resourceTypes
        },
        recommendations: [
          `Server has ${resources.length} resources - Good variety`,
          `${commonResources.length} framework resources detected`,
          `${customResources.length} custom resources found`,
          'All resources are accessible for extraction'
        ]
      };
      
      console.log(`✅ Analysis complete: ${resources.length} resources analyzed`);
      
      setAnalysis(result);
      onAnalysisComplete?.(result);
    } catch (err) {
      console.error('❌ Analysis failed:', err);
      setError(err instanceof Error ? err.message : 'Analysis failed');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getResourceTypeColor = (type: string) => {
    const colorMap: Record<string, string> = {
      'esx_': 'text-blue-400',
      'qb-': 'text-purple-400',
      'vrp_': 'text-green-400',
      'ox_': 'text-orange-400',
      'mythic_': 'text-red-400',
      'standalone_': 'text-cyan-400'
    };
    return colorMap[type] || 'text-gray-400';
  };

  return (
    <div className="glass-morphism-advanced p-6 rounded-2xl border border-orange-400/30">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-gradient-to-br from-orange-400/20 to-red-500/20 rounded-lg border border-orange-400/30">
            <BarChart3 className="w-5 h-5 text-orange-400" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white holographic-effect">Server Analyzer</h3>
            <p className="text-gray-400 text-sm">Analyze server resources and performance</p>
            <div className="text-xs text-orange-400 font-mono fxap-decrypt-animation">FXAP Resource Scanner</div>
          </div>
        </div>
        
        <button
          onClick={analyzeServer}
          disabled={isAnalyzing}
          className={`flex items-center space-x-2 px-6 py-3 rounded-xl font-semibold transition-all ${
            isAnalyzing
              ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/50 cursor-not-allowed'
              : 'bg-orange-500/20 text-orange-400 border border-orange-500/50 hover:bg-orange-500/30 hover:shadow-lg hover:shadow-orange-400/20'
          }`}
        >
          <Search className={`w-5 h-5 ${isAnalyzing ? 'animate-spin' : ''}`} />
          <span>{isAnalyzing ? 'ANALYZING SERVER...' : 'ANALYZE SERVER RESOURCES'}</span>
        </button>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-500/20 border border-red-500/50 rounded-lg flex items-center space-x-2">
          <AlertCircle className="w-4 h-4 text-red-400" />
          <span className="text-red-400 text-sm">{error}</span>
        </div>
      )}

      {analysis && (
        <div className="space-y-6">
          {/* Server Info */}
          {analysis.serverInfo && (
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-gray-800/30 rounded-lg border border-gray-700">
                <div className="flex items-center space-x-2 mb-2">
                  <Server className="w-4 h-4 text-blue-400" />
                  <span className="text-sm text-gray-400">Server Name</span>
                </div>
                <p className="text-white font-medium truncate">
                  {analysis.serverInfo.Data?.hostname || 'Unknown'}
                </p>
              </div>
              
              <div className="p-4 bg-gray-800/30 rounded-lg border border-gray-700">
                <div className="flex items-center space-x-2 mb-2">
                  <Users className="w-4 h-4 text-green-400" />
                  <span className="text-sm text-gray-400">Players</span>
                </div>
                <p className="text-white font-medium">
                  {analysis.serverInfo.Data?.clients || 0} / {analysis.serverInfo.Data?.sv_maxclients || 0}
                </p>
              </div>
            </div>
          )}

          {/* Resource Analysis */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-orange-400 flex items-center neon-glow">
              <Package className="w-5 h-5 mr-2 quantum-particle" />
              Resource Analysis
            </h4>
            
            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 bg-gray-800/30 rounded-lg border border-gray-700 text-center">
                <div className="text-2xl font-bold text-cyan-400 chacha20-effect">
                  {analysis.resourceAnalysis.totalResources}
                </div>
                <div className="text-sm text-gray-400">Total Resources</div>
              </div>
              
              <div className="p-4 bg-gray-800/30 rounded-lg border border-gray-700 text-center">
                <div className="text-2xl font-bold text-green-400 lua-decompile-effect">
                  {analysis.resourceAnalysis.commonResources.length}
                </div>
                <div className="text-sm text-gray-400">Common</div>
              </div>
              
              <div className="p-4 bg-gray-800/30 rounded-lg border border-gray-700 text-center">
                <div className="text-2xl font-bold text-purple-400 fxap-decrypt-animation">
                  {analysis.resourceAnalysis.customResources.length}
                </div>
                <div className="text-sm text-gray-400">Custom</div>
              </div>
            </div>

            {/* Resource Types */}
            {Object.keys(analysis.resourceAnalysis.resourceTypes).length > 0 && (
              <div>
                <h5 className="text-md font-medium text-gray-300 mb-3">Resource Types</h5>
                <div className="grid grid-cols-2 gap-2">
                  {Object.entries(analysis.resourceAnalysis.resourceTypes)
                    .sort(([,a], [,b]) => (b as number) - (a as number))
                    .slice(0, 8)
                    .map(([type, count]) => (
                      <div key={type} className="flex justify-between items-center p-2 bg-gray-800/20 rounded">
                        <span className={`text-sm font-mono ${getResourceTypeColor(type)}`}>
                          {type}
                        </span>
                        <span className="text-sm text-gray-400">{count}</span>
                      </div>
                    ))}
                </div>
              </div>
            )}
          </div>

          {/* Recommendations */}
          {analysis.recommendations.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-lg font-semibold text-yellow-400 flex items-center neon-glow">
                <CheckCircle className="w-5 h-5 mr-2 quantum-particle" />
                Recommendations
              </h4>
              
              <div className="space-y-2">
                {analysis.recommendations.map((rec: string, index: number) => (
                  <div key={index} className="flex items-start space-x-2 p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
                    <CheckCircle className="w-4 h-4 text-yellow-400 mt-0.5 flex-shrink-0" />
                    <span className="text-yellow-200 text-sm">{rec}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ServerAnalyzer;