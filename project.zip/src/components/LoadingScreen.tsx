import React, { useState, useEffect } from 'react';
import { Shield, Zap, Lock } from 'lucide-react';

const LoadingScreen: React.FC = () => {
  const [decryptionText, setDecryptionText] = useState('');
  const [phase, setPhase] = useState(0);
  const [progress, setProgress] = useState(0);

  const phrases = [
    'INITIALIZING FXAP DECRYPTION MATRIX...',
    'MODIFYING FIVEM DLL COMPONENTS...',
    'LOADING CHACHA20 CIPHER ENGINE...',
    'BYPASSING FIVEM SECURITY PROTOCOLS...',
    'LOADING UNLUAC54.JAR DECOMPILER...',
    'UDG V 5.0 FXAP SYSTEMS FULLY OPERATIONAL'
  ];

  useEffect(() => {
    const phaseInterval = setInterval(() => {
      setPhase(prev => {
        if (prev < phrases.length - 1) {
          return prev + 1;
        }
        return prev;
      });
    }, 900);

    const progressInterval = setInterval(() => {
      setProgress(prev => {
        if (prev < 100) {
          return Math.min(100, prev + Math.random() * 3);
        }
        return 100;
      });
    }, 100);

    return () => {
      clearInterval(phaseInterval);
      clearInterval(progressInterval);
    };
  }, [phrases.length]);
  
  useEffect(() => {
    const currentPhrase = phrases[phase] || '';
    let index = 0;
    setDecryptionText('');
    
    const typeInterval = setInterval(() => {
      if (index < currentPhrase.length) {
        setDecryptionText(currentPhrase.substring(0, index + 1));
        index++;
      } else {
        clearInterval(typeInterval);
      }
    }, 40);

    return () => clearInterval(typeInterval);
  }, [phase]);

  return (
    <div className="fixed inset-0 bg-black flex items-center justify-center z-50 overflow-hidden">
      {/* Animated circuit background */}
      <div className="absolute inset-0 opacity-10">
        <div className="circuit-animation"></div>
      </div>
      
      {/* Matrix rain effect */}
      <div className="absolute inset-0 opacity-5">
        <div className="matrix-rain-loading"></div>
      </div>
      
      <div className="text-center z-10 space-y-12 max-w-2xl mx-auto px-8">
        {/* Main logo with advanced effects */}
        <div className="relative">
          <div className="absolute -inset-8 bg-gradient-to-r from-cyan-400/20 via-blue-500/20 to-purple-500/20 rounded-full blur-3xl animate-pulse-slow"></div>
          <div className="relative flex items-center justify-center space-x-4">
            <div className="relative">
              <Shield className="w-32 h-32 text-cyan-400 animate-spin-slow" />
              <div className="absolute inset-0 flex items-center justify-center">
                <Lock className="w-12 h-12 text-blue-400 animate-pulse" />
              </div>
            </div>
            <Zap className="w-16 h-16 text-yellow-400 animate-bounce" />
          </div>
        </div>
        
        {/* Enhanced title with multiple effects */}
        <div className="space-y-4">
          <h1 className="text-8xl font-black bg-gradient-to-r from-cyan-400 via-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent relative">
            UDG V 5.0
          </h1>
          <div className="relative">
            <p className="text-2xl text-gray-300 tracking-[0.3em] font-light">FXAP DECRYPTION READY</p>
            <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-64 h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent"></div>
          </div>
          <p className="text-lg text-gray-500 tracking-widest">ADVANCED FXAP DECRYPTION & LUA DECOMPILATION SYSTEM</p>
        </div>
        
        {/* Advanced decryption text with typewriter effect */}
        <div className="h-12 flex items-center justify-center">
          <p className="text-green-400 font-mono text-xl tracking-wider terminal-cursor bg-black/50 px-6 py-2 rounded-lg border border-green-400/30 typing-effect">
            {decryptionText}
          </p>
        </div>
        
        {/* Enhanced progress section */}
        <div className="space-y-6">
          <div className="w-96 mx-auto">
            <div className="flex justify-between text-sm text-gray-400 mb-2">
              <span>FXAP INITIALIZATION</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <div className="h-3 bg-gray-800 rounded-full overflow-hidden border border-gray-700">
              <div 
                className="h-full progress-bar relative"
                style={{ width: `${progress}%` }}
              >
                <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
              </div>
            </div>
          </div>
          
          {/* Status indicators */}
          <div className="flex justify-center space-x-8">
            {['DLL-MOD', 'CHACHA20', 'FXAP', 'UNLUAC', 'GRANTS'].map((status, i) => (
              <div key={status} className="text-center">
                <div className={`w-3 h-3 rounded-full mx-auto mb-2 ${
                  phase > i ? 'bg-green-400 animate-pulse' : 'bg-gray-600'
                } transition-all duration-500`}></div>
                <span className={`text-xs ${
                  phase > i ? 'text-green-400' : 'text-gray-500'
                } transition-colors duration-500`}>{status}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoadingScreen;