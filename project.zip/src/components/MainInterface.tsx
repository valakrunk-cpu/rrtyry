import React, { useState, useEffect } from 'react';
import ConfigurationPanel from './ConfigurationPanel';
import DecryptionConsole from './DecryptionConsole';
import StatusMonitor from './StatusMonitor';
import DecryptionEffect from './DecryptionEffect';
import ServerAnalyzer from './ServerAnalyzer';
import { FiveMDownloader, ServerConfig, DownloadProgress } from '../utils/fivemDownloader';
import { UDGKeyService } from '../utils/supabase';

interface MainInterfaceProps {
  systemReady: boolean;
}

const MainInterface: React.FC<MainInterfaceProps> = ({ systemReady }) => {
  const [activeDecryption, setActiveDecryption] = useState(false);
  const [decryptionProgress, setDecryptionProgress] = useState(0);
  const [downloadProgress, setDownloadProgress] = useState<DownloadProgress[]>([]);
  const [downloader, setDownloader] = useState<FiveMDownloader | null>(null);
  const [config, setConfig] = useState<ServerConfig>({
    skipResources: [
      "yarn", "webpack", "sessionmanager", "sessionmanager-rdr3",
      "basic-gamemode", "rconlog", "hardcap", "mapmanager",
      "chat", "spawnmanager", "fivem", "fivem-map-skater", "fivem-map-hipster"
    ],
    cfxUrl: "cfx.re/join/example",
    autoOpenCacheFolder: true,
    cacheFiles: true,
    streamSemaphore: 5
  });
  
  const [serverFound, setServerFound] = useState(false);
  const [serverData, setServerData] = useState<any>(null);
  const [showUDGPrompt, setShowUDGPrompt] = useState(false);
  const [udgKey, setUdgKey] = useState('');
  const [dumpCompleted, setDumpCompleted] = useState(false);
  const [showDownloadButton, setShowDownloadButton] = useState(false);
  const [dumpResults, setDumpResults] = useState<{
    totalSize: number;
    resourceCount: number;
    fileName: string;
    resources: string[];
  } | null>(null);

  useEffect(() => {
    const newDownloader = new FiveMDownloader(config);
    setDownloader(newDownloader);
  }, [config]);

  const [notification, setNotification] = useState<{
    type: 'success' | 'error' | 'info' | 'warning';
    title: string;
    message: string;
    show: boolean;
  }>({ type: 'info', title: '', message: '', show: false });

  const showNotification = (type: 'success' | 'error' | 'info' | 'warning', title: string, message: string) => {
    setNotification({ type, title, message, show: true });
    setTimeout(() => {
      setNotification(prev => ({ ...prev, show: false }));
    }, 5000);
  };

  const validateServer = async () => {
    try {
      if (!config.cfxUrl || !config.cfxUrl.includes('cfx.re/join/')) {
        showNotification('error', 'Invalid URL', 'Please enter a valid CFX.re join URL (e.g., cfx.re/join/abc123)');
        return;
      }
      
      // Extract server code from CFX URL
      const match = config.cfxUrl.match(/cfx\.re\/join\/([a-zA-Z0-9]+)/);
      if (!match) {
        showNotification('error', 'Invalid Format', 'CFX.re join URL format is incorrect');
        return;
      }
      
      const serverCode = match[1];
      showNotification('info', 'Validating Server', 'Connecting to FiveM.net API...');
      
      try {
        // Try multiple FiveM.net API endpoints
        let foundServer = null;
        
        // Method 1: Direct server lookup
        try {
          const directResponse = await fetch(`https://servers-frontend.fivem.net/api/servers/single/${serverCode}`, {
            headers: { 
              'Accept': 'application/json',
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
          });
          
          if (directResponse.ok) {
            foundServer = await directResponse.json();
            console.log('🔍 Direct API lookup successful:', foundServer);
          }
        } catch (directError) {
          console.warn('Direct lookup failed:', directError);
        }
        
        // Method 2: Try streamedlist endpoint
        if (!foundServer || !foundServer.Data) {
          try {
            const streamResponse = await fetch('https://servers-frontend.fivem.net/api/servers/streamedlist/', {
              headers: { 
                'Accept': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
              }
            });
            
            if (streamResponse.ok) {
              const serverList = await streamResponse.json();
              console.log('🔍 Searching in server list...');
              
              if (Array.isArray(serverList)) {
                foundServer = serverList.find((server: any) => {
                  return server.id === serverCode || 
                         server.EndPoint?.includes(serverCode) ||
                         (server.connectEndPoints?.[0] && server.connectEndPoints[0].includes(serverCode));
                });
                
                if (foundServer) {
                  foundServer = { Data: foundServer };
                  console.log('🔍 Found server in list:', foundServer);
                }
              }
            }
          } catch (streamError) {
            console.warn('Stream list lookup failed:', streamError);
          }
        }
        
        if (!foundServer || !foundServer.Data) {
          showNotification('error', 'Server Not Found', 'Server not found in FiveM.net database. Please verify the join URL.');
          setServerFound(false);
          return;
        }
        
        setServerData(foundServer);
        setServerFound(true);
        
        const serverInfo = foundServer.Data;
        console.log('📊 Server data:', serverInfo);
        
        showNotification('success', 'Server Validated', 
          `${serverInfo.hostname || 'Unknown Server'} • ${serverInfo.clients || 0}/${serverInfo.sv_maxclients || 0} players`);
        
        // Auto-analyze server resources after validation
        console.log(`🔍 Auto-analyzing server: ${serverInfo.hostname}`);
        if (downloader) {
          try {
            const resources = await downloader.getResourcesList();
            console.log(`📦 Server resources detected (${resources.length} total):`);
            resources.forEach((resource, index) => {
              console.log(`  ${(index + 1).toString().padStart(2, '0')}. ${resource}`);
            });
            console.log(`📊 Analysis complete: ${resources.length} resources available for extraction`);
          } catch (error) {
            console.warn('❌ Auto-analysis failed:', error);
          }
        }
        
      } catch (apiError) {
        console.error('FiveM.net API Error:', apiError);
        showNotification('error', 'API Error', 'FiveM.net API is currently unavailable. Please try again later.');
        setServerFound(false);
      }
      
    } catch (error) {
      showNotification('error', 'Connection Failed', 'Failed to validate server. Please check your internet connection.');
      setServerFound(false);
    }
  };
  
  const handleStartDecryption = async () => {
    if (!serverFound) {
      showNotification('error', 'Server Required', 'Please validate the server first using the "Validate Server" button.');
      return;
    }
    
    setActiveDecryption(true);
    setDecryptionProgress(0);
    setDownloadProgress([]);
    setDumpCompleted(false);
    setShowDownloadButton(false);
    setDumpResults(null);
    
    if (!downloader) return;
    
    try {
      // Random duration between 10-15 minutes
      const durationMinutes = Math.floor(Math.random() * 6 + 10);
      const totalDuration = durationMinutes * 60 * 1000;
      
      // Generate fixed results at start
      const totalSizeGB = Math.floor(Math.random() * 40 + 40);
      const resources = await downloader.getResourcesList();
      const serverName = serverData?.Data?.hostname || 'FiveM_Server';
      const fileName = `${serverName.replace(/[^a-zA-Z0-9]/g, '_')}_Resources_${totalSizeGB}GB.zip`;
      
      console.log(`🚀 Starting server dump: ${serverName}`);
      console.log(`📊 Estimated size: ${totalSizeGB}GB`);
      console.log(`⏱️ Estimated time: ${durationMinutes} minutes`);
      console.log(`📦 Resources found: ${resources.length}`);
      
      const startTime = Date.now();
      let processedResources = 0;
      
      const progressTimer = setInterval(() => {
        const elapsed = Date.now() - startTime;
        const progressPercent = Math.min((elapsed / totalDuration) * 100, 100);
        setDecryptionProgress(Math.round(progressPercent));
        
        // Process resources gradually during dump
        const expectedProcessed = Math.floor((progressPercent / 100) * resources.length);
        
        while (processedResources < expectedProcessed && processedResources < resources.length) {
          const resource = resources[processedResources];
          
          console.log(`🔓 Decrypting: ${resource}`);
          
          setDownloadProgress(prev => {
            const newProgress = {
              filename: resource,
              progress: 100,
              status: 'completed' as const
            };
            return [...prev, newProgress];
          });
          
          processedResources++;
        }
        
        if (progressPercent >= 100) {
          clearInterval(progressTimer);
          setDumpCompleted(true);
          setShowDownloadButton(true);
          
          console.log(`✅ Dump complete: ${resources.length} resources (${totalSizeGB}GB)`);
          
          setDumpResults({
            totalSize: totalSizeGB,
            resourceCount: resources.length,
            fileName,
            resources: resources
          });
          
          showNotification('success', 'Dump Complete', `${resources.length} resources (${totalSizeGB}GB) ready for download.`);
        }
      }, 1000);
      
    } catch (error) {
      console.error('Dump failed:', error);
      showNotification('error', 'Dump Failed', error instanceof Error ? error.message : 'Unknown error occurred');
    } finally {
      setTimeout(() => setActiveDecryption(false), 3000);
    }
  };
  
  const handleDownloadClick = () => {
    setShowUDGPrompt(true);
  };
  
  const handleUDGKeySubmit = async () => {
    if (!udgKey) {
      showNotification('error', 'Key Required', 'Please enter your UDG V 5.0 KEY');
      return;
    }
    
    // Show validating message
    showNotification('info', 'Validating Key', 'Authenticating with UDG V 5.0 servers...');
    
    try {
      // Validate key with Supabase
      const validation = await UDGKeyService.validateKey(udgKey);
      
      if (!validation.valid) {
        showNotification('error', 'Authentication Failed', validation.message);
        return;
      }
      
      setShowUDGPrompt(false);
      
      // Key is valid, proceed with download
      showNotification('success', 'Authentication Success', validation.message);
      
      // Start download process
      setTimeout(() => {
        showNotification('info', 'Download Started', 'Preparing encrypted resource archive...');
        
        // Simulate file download
        setTimeout(() => {
          if (dumpResults) {
            const link = document.createElement('a');
            link.href = '#';
            link.download = dumpResults.fileName;
            link.click();
            
            showNotification('success', 'Download Complete', 
              `${dumpResults.totalSize}GB of decrypted resources downloaded successfully!`);
            
            // Log successful download
            console.log(`✅ Download completed with UDG key: ${udgKey}`);
            console.log(`💾 File: ${dumpResults.fileName}`);
            console.log(`📊 Size: ${dumpResults.totalSize}GB`);
          }
        }, 3000);
      }, 1000);
      
    } catch (error) {
      console.error('UDG key validation error:', error);
      showNotification('error', 'Validation Error', 'Unable to connect to UDG authentication servers');
    }
  };
  


  return (
    <div className="min-h-screen pt-8 pb-12 px-8 relative">
      {activeDecryption && (
        <DecryptionEffect 
          progress={decryptionProgress}
          onComplete={() => setActiveDecryption(false)}
        />
      )}
      
      <div className={`max-w-7xl mx-auto transition-all duration-1000 ${
        systemReady ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
      }`}>
        
        {/* Main title section */}
        <div className="text-center mb-12 space-y-4">
          <h2 className="text-6xl font-black bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
            SERVER DUMP & DECRYPT CENTER
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Advanced FiveM server resource dumping and FXAP decryption system. 
            Extract, decrypt and download all server resources with UDG V 5.0 authentication.
          </p>
          <div className="mt-4 text-sm text-cyan-400 font-mono modern-glow">
            <span>Master Key: 0xb3cb2e04...fb</span> | 
            <span>CFX.re API: Connected</span> | 
            <span>FiveM DLLs: Modified</span> | 
            <span>Server: {serverFound ? 'Validated' : 'Not Validated'}</span>
          </div>
          <div className="flex items-center justify-center space-x-4 mt-6">
            <div className="px-3 py-1 bg-red-400/20 text-red-400 rounded-full text-sm border border-red-400/30">
              DLL Modified
            </div>
            <div className="px-3 py-1 bg-green-400/20 text-green-400 rounded-full text-sm border border-green-400/30">
              ChaCha20 Ready
            </div>
            <div className="px-3 py-1 bg-blue-400/20 text-blue-400 rounded-full text-sm border border-blue-400/30">
              unluac54.jar Loaded
            </div>
            <div className="px-3 py-1 bg-purple-400/20 text-purple-400 rounded-full text-sm border border-purple-400/30">
              Server Dumper
            </div>
          </div>
          <div className="w-32 h-1 bg-gradient-to-r from-cyan-400 to-purple-400 mx-auto rounded-full"></div>
        </div>

        {/* Main interface grid */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 mb-8">
          {/* Configuration Panel */}
          <div className={`xl:col-span-2 space-y-8 ${dumpCompleted ? 'xl:col-span-3' : ''}`}>
            <ConfigurationPanel 
              config={config}
              onConfigChange={setConfig}
              onStartDecryption={handleStartDecryption}
              onValidateServer={validateServer}
              isDecrypting={activeDecryption}
              serverFound={serverFound}
              serverData={serverData}
              dumpCompleted={dumpCompleted}
              onDownloadClick={handleDownloadClick}
            />
            
            {serverFound && (
              <ServerAnalyzer 
                config={config}
                onAnalysisComplete={(analysis) => {
                  console.log('📊 Server analysis completed:', analysis);
                  console.log(`📦 Resources breakdown:`);
                  console.log(`  - Total: ${analysis.resourceAnalysis.totalResources}`);
                  console.log(`  - Common: ${analysis.resourceAnalysis.commonResources.length}`);
                  console.log(`  - Custom: ${analysis.resourceAnalysis.customResources.length}`);
                }}
              />
            )}
            
            <DecryptionConsole 
              isActive={activeDecryption}
              progress={decryptionProgress}
              downloadProgress={downloadProgress}
            />
            
            {/* Dump Results Panel */}
            {dumpCompleted && dumpResults && (
              <div className="glass-morphism-advanced p-8 rounded-2xl border border-green-400/30 bg-gradient-to-br from-green-500/5 to-emerald-500/5">
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center space-x-4">
                    <div className="relative">
                      <div className="w-16 h-16 bg-gradient-to-br from-yellow-400/20 to-orange-500/20 rounded-2xl border border-yellow-400/30 flex items-center justify-center">
                        <svg className="w-10 h-10 text-yellow-400" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M10 4H4c-1.11 0-2 .89-2 2v12c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2h-8l-2-2z"/>
                        </svg>
                      </div>
                      <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-400 rounded-full animate-pulse"></div>
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-white">{serverData?.Data?.hostname || 'FiveM Server'}</h3>
                      <p className="text-gray-400">Server dump completed successfully</p>
                      <p className="text-green-400 text-sm font-mono mt-1">✓ {dumpResults.resourceCount} resources extracted</p>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-4xl font-bold text-green-400">{dumpResults.totalSize}GB</div>
                    <div className="text-sm text-gray-400">Archive Size</div>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                  <div className="p-4 bg-gray-800/40 rounded-xl border border-gray-700 text-center">
                    <div className="text-2xl font-bold text-cyan-400">{dumpResults.resourceCount}</div>
                    <div className="text-sm text-gray-400">Resources</div>
                  </div>
                  
                  <div className="p-4 bg-gray-800/40 rounded-xl border border-gray-700 text-center">
                    <div className="text-2xl font-bold text-blue-400">{dumpResults.totalSize}GB</div>
                    <div className="text-sm text-gray-400">Total Size</div>
                  </div>
                  
                  <div className="p-4 bg-gray-800/40 rounded-xl border border-gray-700 text-center">
                    <div className="text-2xl font-bold text-purple-400">ZIP</div>
                    <div className="text-sm text-gray-400">Format</div>
                  </div>
                  
                  <div className="p-4 bg-gray-800/40 rounded-xl border border-gray-700 text-center">
                    <div className="text-2xl font-bold text-green-400">100%</div>
                    <div className="text-sm text-gray-400">Complete</div>
                  </div>
                </div>
                
                <div className="mb-8">
                  <div className="flex items-center justify-center p-6 bg-gray-800/30 rounded-xl border border-gray-700">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-yellow-400/20 rounded-lg flex items-center justify-center">
                        <svg className="w-8 h-8 text-yellow-400" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M10 4H4c-1.11 0-2 .89-2 2v12c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2h-8l-2-2z"/>
                        </svg>
                      </div>
                      <div className="text-left">
                        <p className="text-white font-semibold text-lg">{dumpResults.fileName}</p>
                        <p className="text-gray-400">{dumpResults.totalSize}GB • ZIP Archive • {dumpResults.resourceCount} Resources</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mb-8">
                  <h4 className="text-lg font-semibold text-cyan-400 mb-4 flex items-center">
                    <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                    </svg>
                    Extracted Resources ({dumpResults.resourceCount})
                  </h4>
                  <div className="max-h-48 overflow-y-auto bg-gray-800/20 rounded-lg p-4 border border-gray-700">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {dumpResults.resources.map((resource, index) => (
                        <div key={index} className="flex items-center space-x-2 p-2 bg-gray-800/30 rounded text-sm">
                          <div className="w-2 h-2 bg-green-400 rounded-full flex-shrink-0"></div>
                          <span className="text-gray-300 font-mono truncate">{resource}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                
                <button
                  onClick={handleDownloadClick}
                  className="w-full flex items-center justify-center space-x-4 px-8 py-6 rounded-2xl font-bold text-xl transition-all duration-300 bg-gradient-to-r from-green-500/20 to-emerald-500/20 text-green-400 border-2 border-green-500/50 hover:from-green-500/30 hover:to-emerald-500/30 hover:border-green-400 hover:shadow-2xl hover:shadow-green-400/20 hover:scale-105"
                >
                  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  <span>DOWNLOAD {dumpResults.totalSize}GB RESOURCES</span>
                  <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                </button>
              </div>
            )}
          </div>
          
          {/* Status Monitor */}
          <div>
            <StatusMonitor 
              config={config}
              isDecrypting={activeDecryption}
              progress={decryptionProgress}
            />
          </div>
        </div>
      </div>
      
      {/* Modern Notification */}
      {notification.show && (
        <div className="fixed top-4 right-4 z-50 animate-fade-in">
          <div className={`max-w-sm w-full bg-gray-900/95 backdrop-blur-xl border rounded-2xl p-4 shadow-2xl ${
            notification.type === 'success' ? 'border-green-400/50' :
            notification.type === 'error' ? 'border-red-400/50' :
            notification.type === 'warning' ? 'border-yellow-400/50' :
            'border-blue-400/50'
          }`}>
            <div className="flex items-start space-x-3">
              <div className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center ${
                notification.type === 'success' ? 'bg-green-400/20' :
                notification.type === 'error' ? 'bg-red-400/20' :
                notification.type === 'warning' ? 'bg-yellow-400/20' :
                'bg-blue-400/20'
              }`}>
                <div className={`w-2 h-2 rounded-full ${
                  notification.type === 'success' ? 'bg-green-400' :
                  notification.type === 'error' ? 'bg-red-400' :
                  notification.type === 'warning' ? 'bg-yellow-400' :
                  'bg-blue-400'
                } animate-pulse`}></div>
              </div>
              <div className="flex-1 min-w-0">
                <p className={`text-sm font-medium ${
                  notification.type === 'success' ? 'text-green-400' :
                  notification.type === 'error' ? 'text-red-400' :
                  notification.type === 'warning' ? 'text-yellow-400' :
                  'text-blue-400'
                }`}>
                  {notification.title}
                </p>
                <p className="text-sm text-gray-300 mt-1">
                  {notification.message}
                </p>
              </div>
              <button
                onClick={() => setNotification(prev => ({ ...prev, show: false }))}
                className="flex-shrink-0 text-gray-400 hover:text-white transition-colors"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* UDG Key Prompt Modal */}
      {showUDGPrompt && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-gray-900/95 backdrop-blur-xl border border-cyan-400/50 rounded-2xl p-8 max-w-md w-full mx-4 shadow-2xl">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-cyan-400/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">UDG V 5.0 Authentication Required</h3>
              <p className="text-gray-400">Enter your UDG V 5.0 KEY to download decrypted resources</p>
              <p className="text-xs text-yellow-400 mt-2">⚠️ Keys are validated against secure Supabase database</p>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">UDG V 5.0 KEY</label>
                <input
                  type="text"
                  value={udgKey}
                  onChange={(e) => setUdgKey(e.target.value.toUpperCase())}
                  className="w-full bg-gray-800/50 border border-gray-600 rounded-lg px-4 py-3 text-white focus:border-cyan-400 focus:outline-none transition-colors font-mono text-center"
                  placeholder="UDG-XXXX-XXXX-XXXX"
                  maxLength={17}
                />
              </div>
              

              
              <div className="flex space-x-3">
                <button
                  onClick={() => setShowUDGPrompt(false)}
                  className="flex-1 px-4 py-3 bg-gray-700/50 text-gray-400 rounded-lg border border-gray-600 hover:bg-gray-600/50 transition-all"
                >
                  Cancel
                </button>
                <button
                  onClick={handleUDGKeySubmit}
                  className="flex-1 px-4 py-3 bg-cyan-500/20 text-cyan-400 rounded-lg border border-cyan-500/50 hover:bg-cyan-500/30 transition-all"
                >
                  Download Resources
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MainInterface;