import React, { useState, useEffect } from 'react';
import ServerStats from './ServerStats';
import ResourceList from './ResourceList';
import PlayerList from './PlayerList';
import SystemMonitoring from './SystemMonitoring';
import DecryptionEffect from './DecryptionEffect';

interface DashboardProps {
  activePanel: string;
}

const Dashboard: React.FC<DashboardProps> = ({ activePanel }) => {
  const [showDecryption, setShowDecryption] = useState(false);

  const handleResourceAction = () => {
    setShowDecryption(true);
    setTimeout(() => setShowDecryption(false), 3000);
  };

  const renderPanel = () => {
    switch (activePanel) {
      case 'resources':
        return <ResourceList onAction={handleResourceAction} />;
      case 'players':
        return <PlayerList />;
      case 'monitoring':
        return <SystemMonitoring />;
      default:
        return (
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            <div className="xl:col-span-2">
              <ServerStats />
            </div>
            <div>
              <SystemMonitoring compact />
            </div>
            <div className="lg:col-span-2">
              <ResourceList onAction={handleResourceAction} compact />
            </div>
            <div>
              <PlayerList compact />
            </div>
          </div>
        );
    }
  };

  return (
    <div className="p-6 relative min-h-full">
      {showDecryption && <DecryptionEffect />}
      
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h2 className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent mb-2">
            {activePanel === 'dashboard' ? 'Command Center' : activePanel.charAt(0).toUpperCase() + activePanel.slice(1)}
          </h2>
          <p className="text-gray-400">Advanced FiveM server management interface</p>
        </div>

        <div className="fade-in-stagger">
          {renderPanel()}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;